const mongoose = require('mongoose')
const Schema = mongoose.Schema

const employeeSchema = new Schema ({
    name: {
        type: String
    },
    price: {
        type: Number
    },
    publisher: {
        type: String
    },
    phone: {
        type: String
    },
    book_id: {
        type: Number
    }
}, {timestamps: true})

const Employee = mongoose.model('Employee', employeeSchema)
module.exports = Employee